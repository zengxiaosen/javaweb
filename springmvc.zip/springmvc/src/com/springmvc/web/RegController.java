package com.springmvc.web;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;
import com.springmvc.entity.Users;

public class RegController extends SimpleFormController {
	@Override
	protected ModelAndView onSubmit(HttpServletRequest request,
			HttpServletResponse response, Object command, BindException errors)
			throws Exception {
		//��ȡ�û�����
		Users user=(Users)command;		
		//����һ��ָ����ͼ�߼�����ModelAndViewʵ��
		ModelAndView mav=new ModelAndView("show");	
		//��mavʵ��ָ������ģ��
		mav.addObject("user", user);
		//����mavʵ��
		return mav;
	}
	
	//�������ݸ�ʽת��
	@Override
	protected void initBinder(HttpServletRequest request,
			ServletRequestDataBinder binder) throws Exception {
		binder.registerCustomEditor(Date.class, new CustomDateEditor(new SimpleDateFormat("yyyy-MM-dd"), true));
	}
	
	//Ϊע�������"���������б�"�ṩ�����б�
	@Override
	protected Map referenceData(HttpServletRequest request) throws Exception {
		Map<String, Object> model=new HashMap<String, Object>();
		model.put("hobbyList", new String[]{"Swimming","Running"});
		return model;
	}

}
