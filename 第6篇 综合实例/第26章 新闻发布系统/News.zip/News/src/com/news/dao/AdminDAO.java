package com.news.dao;

import java.util.List;

import com.news.entity.Admin;

public interface AdminDAO {
	public List search(Admin condition);
}
