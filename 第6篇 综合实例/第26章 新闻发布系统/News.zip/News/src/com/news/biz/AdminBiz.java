package com.news.biz;

import java.util.List;

import com.news.entity.Admin;

public interface AdminBiz {
	public List login(Admin condition);
}
