package com.restrant.dao;

import java.util.List;

public interface MealSeriesDAO {
	//��ȡ��ϵ�б�
	public List getMealSeries();
}
