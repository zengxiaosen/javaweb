package com.restrant.biz;

import java.util.List;

public interface MealSeriesBiz {
	//��ȡ��ϵ�б�
	public List getMealSeries();
}
