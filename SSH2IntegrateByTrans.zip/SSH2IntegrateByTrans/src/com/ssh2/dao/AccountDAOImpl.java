package com.ssh2.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;

import com.ssh2.entity.Account;

public class AccountDAOImpl implements AccountDAO {

	//��������sessionFactory,���ڽ���LocalSessionFactoryBean��ʵ��sessionFactoryע��
	SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	@Override
	public List getAccountByAccountNo(String accountNo) {
		Session session=sessionFactory.getCurrentSession();
		Criteria c=session.createCriteria(Account.class);
		c.add(Restrictions.eq("accountNo", accountNo));
		return c.list();		
	}

	@Override
	public void transfer(Account a1, Account a2) {
		Session session=sessionFactory.getCurrentSession();
		session.update(a1);
		session.update(a2);
		
	}

}
