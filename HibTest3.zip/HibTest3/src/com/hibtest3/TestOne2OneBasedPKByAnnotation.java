package com.hibtest3;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibtest3.entity.*;

public class TestOne2OneBasedPKByAnnotation {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//new TestOne2OneBasedPKByAnnotation().getPeopleZjById(1);
		//new TestOne2OneBasedPKByAnnotation().addPeopleZj();
		new TestOne2OneBasedPKByAnnotation().deleteIdentitycardZjById(8);
	}
	
	private void getPeopleZjById(int i){
		Session session=HibernateSessionFactory.getSession();		
		PeopleZj peopleZj = (PeopleZj)session.get(PeopleZj.class,i);
		System.out.println(peopleZj.getName()+"������֤�ţ�"+peopleZj.getIdentitycardZj().getCardNo());
		session.close();
	}
	
	private void addPeopleZj(){
		PeopleZj peopleZj = new PeopleZj();
		IdentitycardZj identitycardZj = new IdentitycardZj();
		identitycardZj.setCardNo("320107000000000008");		
		peopleZj.setName("Tom");
		peopleZj.setAge(30);
		peopleZj.setSex("��");
		//�����໥����
		peopleZj.setIdentitycardZj(identitycardZj);
		identitycardZj.setPeopleZj(peopleZj);
		//�־û�identitycardZj����
		Session session=HibernateSessionFactory.getSession();		
		Transaction tx = session.beginTransaction();
		session.save(identitycardZj);
		tx.commit();
		session.close();
	}
	
	private void deleteIdentitycardZjById(int id){
		Session session=HibernateSessionFactory.getSession();		
		IdentitycardZj identitycardZj = (IdentitycardZj)session.get(IdentitycardZj.class, id);
		Transaction tx = session.beginTransaction();
		session.delete(identitycardZj);
		tx.commit();
		session.close();
	}


}
