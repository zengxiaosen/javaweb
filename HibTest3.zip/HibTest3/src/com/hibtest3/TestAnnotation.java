package com.hibtest3;
import org.hibernate.*;

import com.hibtest3.entity.Books;
import com.hibtest3.entity.Users;
public class TestAnnotation {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//new TestAnnotation().getUserById(2);		
		new TestAnnotation().getBookById(1);
	}
	
	private void getUserById(int i){
		Session session=HibernateSessionFactory.getSession();
		Users user=(Users)session.get(Users.class, 2);
		System.out.println("���Ϊ2�û���¼��Ϊ��"+user.getLoginName());
	}
	
	private void getBookById(int i){
		Session session=HibernateSessionFactory.getSession();
		Books book=(Books)session.get(Books.class, 4939);
		System.out.println("ͼ�飺"+book.getTitle()+"������Ϊ��"+book.getPublishers().getName());
		//System.out.println("ͼ�飺"+book.getTitle());
	}
}