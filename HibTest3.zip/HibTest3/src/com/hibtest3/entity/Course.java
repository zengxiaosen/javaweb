package com.hibtest3.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

/**
 * Course entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "course", catalog = "bookshop")
public class Course implements java.io.Serializable {

	private Integer courseId;
	private String courseName;
	//����Ԫ������ΪStudent��ѡ��ѧ������students
	private Set<Student> students=new HashSet<Student>();		

	/** default constructor */
	public Course() {
	}

	/** full constructor */
	public Course(String courseName) {
		this.courseName = courseName;
	}
	
	@Id
	@GeneratedValue
	@Column(name = "CourseId", unique = true, nullable = false)
	public Integer getCourseId() {
		return this.courseId;
	}

	public void setCourseId(Integer courseId) {
		this.courseId = courseId;
	}

	@Column(name = "CourseName", length = 16)
	public String getCourseName() {
		return this.courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	//ʹ��@ManyToManyע��ʵ��Course��Student�Ķ�Զ����
	@ManyToMany(mappedBy="courses",fetch=FetchType.EAGER)
	public Set<Student> getStudents() {
		return students;
	}

	public void setStudents(Set<Student> students) {
		this.students = students;
	}

}