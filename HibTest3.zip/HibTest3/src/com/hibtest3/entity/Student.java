package com.hibtest3.entity;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "student", catalog = "bookshop")
public class Student implements java.io.Serializable {

	private Integer studentId;
	private String studentName;	
	//����Ԫ������ΪCourse��ѡ�޿γ̼���courses
	private Set<Course> courses=new HashSet<Course>();	

	/** default constructor */
	public Student() {
	}

	/** full constructor */
	public Student(String studentName) {
		this.studentName = studentName;
	}
	
	@Id
	@GeneratedValue
	@Column(name = "StudentId", unique = true, nullable = false)
	public Integer getStudentId() {
		return this.studentId;
	}

	public void setStudentId(Integer studentId) {
		this.studentId = studentId;
	}

	@Column(name = "StudentName", length = 16)
	public String getStudentName() {
		return this.studentName;
	}

	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	
	//ʹ��@ManyToManyע��ʵ��Student��Course�Ķ�Զ����
	@ManyToMany(fetch=FetchType.EAGER)
	@Cascade(value={CascadeType.SAVE_UPDATE}) 
	@JoinTable(name="sc",
			joinColumns={@JoinColumn(name="Sid")},
			inverseJoinColumns={@JoinColumn(name="Cid")})
	public Set<Course> getCourses() {
		return courses;
	}

	public void setCourses(Set<Course> courses) {
		this.courses = courses;
	}

}