package com.hibtest3.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

/**
 * PeopleZj entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "people_zj", catalog = "bookshop")
public class PeopleZj implements java.io.Serializable {
	private Integer id;
	private String name;
	private String sex;
	private Integer age;
	//����IdentitycardZj���͹�������
    private IdentitycardZj identitycardZj;
    
	/** default constructor */
	public PeopleZj() {
	}

	/** full constructor */
	public PeopleZj(String name, String sex, Integer age) {
		this.name = name;
		this.sex = sex;
		this.age = age;
	}
	
	//����ע�⹦���ǽ���ǰ������identitycardZj���Ե���������Ϊ�����������
	@GenericGenerator(name = "generator", strategy = "foreign",
			parameters=@Parameter(name="property",value="identitycardZj"))
	@Id
	@GeneratedValue(generator = "generator")
	@Column(name = "Id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "Name", length = 10)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Column(name = "Sex", length = 4)
	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	@Column(name = "Age")
	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	//ʹ��@OneToManyע��ʵ��PeopleZj��IdentitycardZj
	//�Ļ���������һ��һ����
	@OneToOne(mappedBy="peopleZj",optional=false)
	public IdentitycardZj getIdentitycardZj() {
		return identitycardZj;
	}

	public void setIdentitycardZj(IdentitycardZj identitycardZj) {
		this.identitycardZj = identitycardZj;
	}

}