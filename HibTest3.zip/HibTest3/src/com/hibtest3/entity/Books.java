package com.hibtest3.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade; 
import org.hibernate.annotations.CascadeType; 


/**
 * Books entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "books", catalog = "bookshop")
public class Books implements java.io.Serializable {
	private Integer id;
	private String title;
	private String author;	
	private Integer unitPrice;	
	//����Publishers���͵Ĺ�������
	private Publishers publishers;	
	//ʹ��@ManyToOne��@JoinColumnע��ʵ��Books��Publishers�Ķ��һ����
	@ManyToOne(fetch=FetchType.EAGER)
	@Cascade(value={CascadeType.SAVE_UPDATE}) 
	@JoinColumn(name="PublisherId")
	public Publishers getPublishers() {
		return publishers;
	}

	public void setPublishers(Publishers publishers) {
		this.publishers = publishers;
	}

	/** default constructor */
	public Books() {
	}

	/** minimal constructor */
	public Books(String title, String author, Integer publisherId) {
		this.title = title;
		this.author = author;		
	}

	/** full constructor */
	public Books(String title, String author, Integer publisherId,
			Integer unitPrice) {
		this.title = title;
		this.author = author;		
		this.unitPrice = unitPrice;
	}

	// Property accessors
	@Id
	@GeneratedValue
	@Column(name = "Id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "Title", nullable = false, length = 50)
	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	@Column(name = "Author", nullable = false, length = 16)
	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}
	

	@Column(name = "UnitPrice", precision = 8, scale = 0)
	public Integer getUnitPrice() {
		return this.unitPrice;
	}

	public void setUnitPrice(Integer unitPrice) {
		this.unitPrice = unitPrice;
	}

}