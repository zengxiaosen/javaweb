package com.hibtest3.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

/**
 * IdentitycardZj entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "identitycard_zj", catalog = "bookshop")
public class IdentitycardZj implements java.io.Serializable {
	private Integer id;
	private String cardNo;
	//����PeopleZj���͵Ĺ�������
	private PeopleZj peopleZj;		

	/** default constructor */
	public IdentitycardZj() {
	}

	/** full constructor */
	public IdentitycardZj(String cardNo) {
		this.cardNo = cardNo;
	}
	
	@Id
	@GeneratedValue
	@Column(name = "Id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "CardNo", length = 18)
	public String getCardNo() {
		return this.cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}
	
	//ʹ��@OneToOne��@PrimaryKeyJoinColumnע��
	//ʵ��IdentitycardZj��PeopleZj�Ļ���������һ��һ����
	@OneToOne(cascade=CascadeType.ALL)
	@PrimaryKeyJoinColumn
	public PeopleZj getPeopleZj() {
		return peopleZj;
	}

	public void setPeopleZj(PeopleZj peopleZj) {
		this.peopleZj = peopleZj;
	}

}