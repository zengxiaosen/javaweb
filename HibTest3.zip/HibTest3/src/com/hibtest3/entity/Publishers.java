package com.hibtest3.entity;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.Cascade; 
import org.hibernate.annotations.CascadeType; 

/**
 * Publishers entity. @author MyEclipse Persistence Tools
 */
@Entity
@Table(name = "publishers", catalog = "bookshop")
public class Publishers implements java.io.Serializable {

	private Integer id;
	private String name;
	//����Ԫ������ΪBooks�Ĺ�����������bks
	private Set<Books> bks=new HashSet<Books>();

	//ʹ��@OneToManyע��ʵ��Publishers��Books��һ�Զ����	
	@OneToMany(mappedBy="publishers",fetch=FetchType.EAGER)
	@Cascade(value={CascadeType.DELETE}) 
	public Set<Books> getBks() {
		return bks;
	}

	public void setBks(Set<Books> bks) {
		this.bks = bks;
	}

	/** default constructor */
	public Publishers() {
	}

	/** full constructor */
	public Publishers(String name) {
		this.name = name;
	}
	
	@Id
	@GeneratedValue
	@Column(name = "Id", unique = true, nullable = false)
	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Column(name = "Name", nullable = false, length = 16)
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

}