package com.assh2.dao;

import java.util.List;
import javax.annotation.Resource;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Example;
import org.springframework.stereotype.Repository;

import com.assh2.entity.Users;

//ʹ��@Repositoryע����Spring������ע����ΪuserDAO��UserDAOImplʵ��
@Repository("userDAO")
public class UserDAOImpl implements UserDAO {
	//ͨ��@Resourceע��ע��Spring�����ļ��е�SessionFactoryʵ��
	@Resource
	SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override	
	public List search(Users condition) {
		List list=null;
		Transaction tx=null;
		Session session=sessionFactory.getCurrentSession();
		try{
			tx=session.beginTransaction();
			Criteria c=session.createCriteria(Users.class);
			Example example=Example.create(condition);
			c.add(example);	
			list= c.list();
			tx.commit();
		}catch(Exception e)	{
			tx.rollback();
		}
		return list;
	}

}
