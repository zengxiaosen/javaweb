package com.assh2.dao;

import java.util.List;

import com.assh2.entity.Users;

public interface UserDAO {
	public List search(Users condition);
}
