package com.assh2.biz;

import java.util.List;

import com.assh2.entity.Users;

public interface UserBiz {
	public List login(Users condition);
}
