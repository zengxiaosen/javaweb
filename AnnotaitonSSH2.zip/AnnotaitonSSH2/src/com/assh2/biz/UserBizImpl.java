package com.assh2.biz;

import java.util.List;
import javax.annotation.Resource;
import org.springframework.stereotype.Service;
import com.assh2.dao.UserDAO;
import com.assh2.entity.Users;

//ʹ��@Serviceע����Spring������ע����ΪuserBiz��UserBizImplʵ��
@Service("userBiz")
public class UserBizImpl implements UserBiz {

	//ʹ��@Resourceע��ע��UserDAOImplʵ��
	@Resource
	UserDAO userDAO;	
	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	
	@Override
	public List login(Users condition) {
		return userDAO.search(condition);
	}

}
