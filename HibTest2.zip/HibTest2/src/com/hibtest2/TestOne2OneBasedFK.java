package com.hibtest2;

import com.hibtest2.dao.BaseHibernateDAO;
import com.hibtest2.entity.Identitycard;
import com.hibtest2.entity.People;

public class TestOne2OneBasedFK extends BaseHibernateDAO {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new TestOne2OneBasedFK().getPeopleById(1);
		//new TestOne2OneBasedFK().getIdentityCardById(1);
		//new TestOne2OneBasedFK().addPeople();
		//new TestOne2OneBasedFK().deletePeopleById(1);
	}
	private void getPeopleById(int i){
		People people = (People)super.get(People.class,i);
		System.out.println(people.getName()+"������֤�ţ�"+people.getIdentitycard().getCardNo());
	}
	
	private void getIdentityCardById(int i){
		Identitycard identitycard = (Identitycard)super.get(Identitycard.class,i);
		System.out.println(identitycard.getCardNo()+"����֤�������ǣ�"+identitycard.getPeople().getName());
	}
	
	private void addPeople(){
		People people = new People();
		Identitycard identitycard = new Identitycard();
		identitycard.setCardNo("320107000000000008");		
		people.setName("Tom");
		people.setAge(30);
		people.setSex("��");
		//�����໥����
		people.setIdentitycard(identitycard);
		identitycard.setPeople(people);
		super.add(people);
	}
	
	private void deletePeopleById(int id){
		People people = (People)super.get(People.class, id);
		super.delete(people);
	}

}
