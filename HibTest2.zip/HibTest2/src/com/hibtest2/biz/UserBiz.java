package com.hibtest2.biz;

public interface UserBiz {
	//��¼��֤
	public boolean checkLogin(String loginName,String loginPwd);

}
