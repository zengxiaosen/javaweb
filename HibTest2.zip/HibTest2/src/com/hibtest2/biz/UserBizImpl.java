package com.hibtest2.biz;

import com.hibtest2.dao.UserDAO;
import com.hibtest2.dao.UserDAOImpl;

public class UserBizImpl implements UserBiz {

	@Override
	public boolean checkLogin(String loginName, String loginPwd) {
		UserDAO userDAO= new UserDAOImpl();		
		return userDAO.validate(loginName, loginPwd);
	}
}
