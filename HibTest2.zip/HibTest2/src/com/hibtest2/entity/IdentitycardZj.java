package com.hibtest2.entity;

/**
 * IdentitycardZj entity. @author MyEclipse Persistence Tools
 */

public class IdentitycardZj implements java.io.Serializable {

	// Fields

	private Integer id;
	private String cardNo;
	//ʹ��PeopleZj���������ԣ���������PeopleZj��Ĺ���
	private PeopleZj peopleZj;

	// Constructors

	public PeopleZj getPeopleZj() {
		return peopleZj;
	}

	public void setPeopleZj(PeopleZj peopleZj) {
		this.peopleZj = peopleZj;
	}

	/** default constructor */
	public IdentitycardZj() {
	}

	/** full constructor */
	public IdentitycardZj(String cardNo) {
		this.cardNo = cardNo;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCardNo() {
		return this.cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

}