package com.hibtest2.entity;

/**
 * Identitycard entity. @author MyEclipse Persistence Tools
 */

public class Identitycard implements java.io.Serializable {

	// Fields

	private Integer id;
	private String cardNo;
	//ʹ��People���������ԣ���������People��Ĺ���
	private People people;

	// Constructors

	public People getPeople() {
		return people;
	}

	public void setPeople(People people) {
		this.people = people;
	}

	/** default constructor */
	public Identitycard() {
	}

	/** full constructor */
	public Identitycard(String cardNo) {
		this.cardNo = cardNo;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getCardNo() {
		return this.cardNo;
	}

	public void setCardNo(String cardNo) {
		this.cardNo = cardNo;
	}

}