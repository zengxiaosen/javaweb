package com.hibtest2.entity;

import java.util.Date;

/**
 * Account1 entity. @author MyEclipse Persistence Tools
 */

public class Account1 implements java.io.Serializable {

	// Fields

	private Integer id;
	private String accountNo;
	private Long balance;
	//����version���ֹ���
	//private Integer version;
	
	//����timestamp���ֹ�������ʾ����޸�ʱ��
	//private Date lastUpdateTime;

	// Constructors

	/*
	public Date getLastUpdateTime() {
		return lastUpdateTime;
	}

	public void setLastUpdateTime(Date lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}
	*/

	/** default constructor */
	public Account1() {
	}

	/** full constructor */
	public Account1(String accountNo, Long balance, Integer version) {
		this.accountNo = accountNo;
		this.balance = balance;
		//this.version = version;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAccountNo() {
		return this.accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public Long getBalance() {
		return this.balance;
	}

	public void setBalance(Long balance) {
		this.balance = balance;
	}

	/*
	public Integer getVersion() {
		return this.version;
	}

	public void setVersion(Integer version) {
		this.version = version;
	}
	*/

}