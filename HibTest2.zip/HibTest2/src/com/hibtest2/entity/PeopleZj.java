package com.hibtest2.entity;

/**
 * PeopleZj entity. @author MyEclipse Persistence Tools
 */

public class PeopleZj implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private String sex;
	private Integer age;
	//ʹ��Identitycard���������ԣ���������Identitycard��Ĺ���
	private IdentitycardZj identitycardZj;
	
	// Constructors

	public IdentitycardZj getIdentitycardZj() {
		return identitycardZj;
	}

	public void setIdentitycardZj(IdentitycardZj identitycardZj) {
		this.identitycardZj = identitycardZj;
	}

	/** default constructor */
	public PeopleZj() {
	}

	/** full constructor */
	public PeopleZj(String name, String sex, Integer age) {
		this.name = name;
		this.sex = sex;
		this.age = age;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

}