package com.hibtest2.entity;

/**
 * People entity. @author MyEclipse Persistence Tools
 */

public class People implements java.io.Serializable {

	// Fields

	private Integer id;
	private String name;
	private String sex;
	private Integer age;
	//private Integer cardId;
	//ʹ��Identitycard���������ԣ���������Identitycard��Ĺ���
	private Identitycard identitycard;
	

	// Constructors

	public Identitycard getIdentitycard() {
		return identitycard;
	}

	public void setIdentitycard(Identitycard identitycard) {
		this.identitycard = identitycard;
	}

	/** default constructor */
	public People() {
	}

	/** full constructor */
	public People(String name, String sex, Integer age, Integer cardId) {
		this.name = name;
		this.sex = sex;
		this.age = age;
		//this.cardId = cardId;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getSex() {
		return this.sex;
	}

	public void setSex(String sex) {
		this.sex = sex;
	}

	public Integer getAge() {
		return this.age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	

}