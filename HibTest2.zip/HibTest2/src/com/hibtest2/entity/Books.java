package com.hibtest2.entity;

/**
 * Books entity. @author MyEclipse Persistence Tools
 */

public class Books implements java.io.Serializable {

	// Fields

	private Integer id;
	private String title;
	private String author;
	private Publishers publishers;
	private Integer unitPrice;

	// Constructors

	public Publishers getPublishers() {
		return publishers;
	}

	public void setPublishers(Publishers publishers) {
		this.publishers = publishers;
	}

	/** default constructor */
	public Books() {
	}

	/** minimal constructor */
	public Books(String title, String author, Integer publisherId) {
		this.title = title;
		this.author = author;
		//����С���Ĺ��췽����ɾ��publisherId���Եĸ�ֵ
		//this.publisherId = publisherId;
	}

	/** full constructor */
	public Books(String title, String author, Integer publisherId,
			Integer unitPrice) {
		this.title = title;
		this.author = author;
		//��full���췽����ɾ��publisherId���Եĸ�ֵ
		//this.publisherId = publisherId;
		this.unitPrice = unitPrice;
	}

	// Property accessors

	public Integer getId() {
		return this.id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getTitle() {
		return this.title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return this.author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}	

	public Integer getUnitPrice() {
		return this.unitPrice;
	}

	public void setUnitPrice(Integer unitPrice) {
		this.unitPrice = unitPrice;
	}

}