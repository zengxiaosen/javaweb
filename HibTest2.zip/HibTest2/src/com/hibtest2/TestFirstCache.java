package com.hibtest2;
import java.io.Serializable;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibtest2.entity.Users;

public class TestFirstCache {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//new TestFirstCache().testGet_1();
		new TestFirstCache().testGet_2();
		//new TestFirstCache().testIterator_1();
		//new TestFirstCache().testIterator_2();
		//new TestFirstCache().testSave_Load();
		//new TestFirstCache().testClear();
	}
	
	
	//��ͬһ��session�з�������get��ѯ
	public void testGet_1(){
        //��ȡsession
		Session session=HibernateSessionFactory.getSession();		
		Users user1=(Users)session.get(Users.class, 1);
		System.out.println(user1.getLoginName());		
		Users user2=(Users)session.get(Users.class, 1);
		System.out.println(user2.getLoginName());
        HibernateSessionFactory.closeSession();
	}
	
	//��������session�з�������get��ѯ
	public void testGet_2(){
        //������һ��Session
		Session session1=HibernateSessionFactory.getSession();		
		Users user1=(Users)session1.get(Users.class, 1);
		System.out.println(user1.getLoginName());	
		//�رյ�һ��Session
		HibernateSessionFactory.closeSession();
		//�����ڶ���Session
		Session session2=HibernateSessionFactory.getSession();	
		Users user2=(Users)session2.get(Users.class, 1);
		System.out.println(user2.getLoginName());
		//�رյڶ���Session
        HibernateSessionFactory.closeSession();
	}
	
	//��ͬһ��session�з�������iterator��ѯ
	public void testIterator_1(){
        //��ȡsession
		Session session=HibernateSessionFactory.getSession();		
		Users user1=(Users)session.createQuery("from Users u where u.id=1").iterate().next();
		System.out.println(user1.getLoginName());		
		Users user2=(Users)session.createQuery("from Users u where u.id=1").iterate().next();
		System.out.println(user2.getLoginName());
        HibernateSessionFactory.closeSession();
	}
	
	//iterate��ѯ���Բ���
	public void testIterator_2(){
        //��ȡsession
		Session session=HibernateSessionFactory.getSession();		
		String loginName1=(String)session.createQuery("select u.loginName from Users u where u.id=1").iterate().next();
		System.out.println(loginName1);		
		String loginName2=(String)session.createQuery("select u.loginName from Users u where u.id=1").iterate().next();
		System.out.println(loginName2);	
        HibernateSessionFactory.closeSession();
	}
	
	
	//��һ��Session����save����ִ��load��ѯ
	public void testSave_Load(){
        //��ȡsession
		Session session=HibernateSessionFactory.getSession();	
		Transaction tx=session.beginTransaction();
		Users user=new Users();
		user.setLoginName("���û�");		
		Serializable id=session.save(user); //�����û�
		tx.commit();
		Users user1=(Users)session.load(Users.class, id);
		System.out.println(user.getLoginName());
        HibernateSessionFactory.closeSession();
	}
	
	
	//��ͬһ��Session���ȵ���load��ѯ��Ȼ��ִ��clear()����������ٵ���load��ѯ
	public void testClear(){
        //��ȡsession
		Session session=HibernateSessionFactory.getSession();	
		Users user1=(Users)session.load(Users.class, 1);		
		System.out.println(user1.getLoginName());
		session.clear();  //���һ�����������ж���
		Users user2=(Users)session.load(Users.class, 1);		
		System.out.println(user2.getLoginName());
        HibernateSessionFactory.closeSession();
	}

}
