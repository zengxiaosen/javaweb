package com.hibtest2;

import com.hibtest2.dao.BaseHibernateDAO;
import com.hibtest2.entity.IdentitycardZj;
import com.hibtest2.entity.PeopleZj;

public class TestOne2OneBasedPK extends BaseHibernateDAO {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		new TestOne2OneBasedPK().getPeopleZjById(1);
		//new TestOne2OneBasedPK().addPeopleZj();
		//new TestOne2OneBasedPK().deleteIdentitycardZjById(1);
	}
	private void getPeopleZjById(int i){
		PeopleZj peopleZj = (PeopleZj)super.get(PeopleZj.class,i);
		System.out.println(peopleZj.getName()+"������֤�ţ�"+peopleZj.getIdentitycardZj().getCardNo());
	}
	
	private void addPeopleZj(){
		PeopleZj peopleZj = new PeopleZj();
		IdentitycardZj identitycardZj = new IdentitycardZj();
		identitycardZj.setCardNo("320107000000000008");		
		peopleZj.setName("Tom");
		peopleZj.setAge(30);
		peopleZj.setSex("��");
		//�����໥����
		peopleZj.setIdentitycardZj(identitycardZj);
		identitycardZj.setPeopleZj(peopleZj);
		super.add(identitycardZj);
	}
	
	private void deleteIdentitycardZjById(int id){
		IdentitycardZj identitycardZj = (IdentitycardZj)super.get(IdentitycardZj.class, id);
		super.delete(identitycardZj);
	}

}
