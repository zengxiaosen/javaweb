package com.hibtest2;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.NotSupportedException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.UserTransaction;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.hibtest2.entity.Users;

public class TestHibernateJTA {

	/**
	 * @param args
	 * @throws SystemException 
	 * @throws NotSupportedException 
	 */
	public static void main(String[] args) throws NotSupportedException, SystemException {
	
		
		//new TestHibernateJTA().saveUserByJTA();  
		
		new TestHibernateJTA().addUserByJDBC();
	}
	
	private void addUserByJDBC(){
		//����ʵ����
		Users user=new Users();
		user.setLoginName("zhangsan");
		user.setLoginPwd("123456");
		//���Sessionʵ��
		Session session=HibernateSessionFactory.getSession();
		Transaction tx=null;
		try {			
	        //��ʼһ������
			tx=session.beginTransaction();
		    //����save�����־û�user����
			session.save(user);
			//�ύ���������ݿ��в���һ���¼�¼
			tx.commit();
		} catch (Exception e) {
			if(tx!=null){
				tx.rollback();  //����ع�
			}
	  		e.printStackTrace();
		}finally{
			HibernateSessionFactory.closeSession();   //�ر�session 
		}
	}

	
	public void saveUserByJTA() throws NotSupportedException, SystemException{
		Users u1=new Users();
		u1.setLoginName("userJTA1");
		u1.setLoginPwd("123456");
		Users u2=new Users();		
		u2.setLoginName("userJTA2");
		u2.setLoginPwd("123456");
		try {
			UserTransaction tx=(UserTransaction)new InitialContext().lookup("java:comp/env/jdbc/bookshop");
			tx.begin();
			Session session = HibernateSessionFactory.getSession();
		    session.save(u1);
		    session.close();
		    
		    Session session1 = HibernateSessionFactory.getSession();
		    session1.save(u2);
		    session.close();
			
			tx.commit();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SecurityException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RollbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HeuristicMixedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (HeuristicRollbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
