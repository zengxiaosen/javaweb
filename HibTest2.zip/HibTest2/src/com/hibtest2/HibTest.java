package com.hibtest2;

import com.hibtest2.dao.*;
import com.hibtest2.entity.Users;

public class HibTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		HibTest hibTest=new HibTest();
		//���β���testAdd��testDelete��testUpdate����
		hibTest.testAdd();
		//hibTest.testDelete(8);		
		//hibTest.testUpdate();
	}
	
   //��������
	public void testAdd(){
		Users users=new Users();
		users.setLoginName("����");
		users.setLoginPwd("123456");	
		UserDAO userDao=new UserDAOImpl();
		userDao.add(users);		
	}	
	
	//ɾ������
	public void testDelete(int id){
		UserDAO userDao=new UserDAOImpl();
		Users users=userDao.get(id);
		userDao.delete(users);
	}
	
	//�޸�����
	public void testUpdate(){
		UserDAO userDao=new UserDAOImpl();
		Users users=userDao.get(2);	
		users.setLoginPwd("210000");
		userDao.update(users);
	}
}
