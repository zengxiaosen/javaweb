package com.ssh2.biz;

import java.util.List;

import com.ssh2.entity.Users;

public interface UserBiz {
	public List login(Users condition);
}
